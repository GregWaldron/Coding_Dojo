import Ninja

greg = Ninja.Ninja("Greg", "Waldron", "Yogi", "Dog")
greg.walk().feed().bathe()

kaitlyn = Ninja.Ninja("Kaitlyn", "Waldron", "Tuco", "Cat")
kaitlyn.feed().feed().bathe()